import React from 'react';
import { Button, Text, View, Image } from 'react-native';
import MaterialIcons from 'react-native-vector-icons/MaterialIcons';
import {Header} from 'react-native-elements';

import SearchBar from '../components/SearchBar';

export default class ThirdScreen extends React.Component{
	onPressSearch = term => {
    	console.log(term);
  	}


		static navigationOptions={
			drawerLabel:'Add Friends',
			drawerIcon:({tintColor})=>{
				return(
					<MaterialIcons
					name="person-add"
					size={24}
					style={{color: tintColor}}
					>
					</MaterialIcons>
				);
			}
		}
		render(){
			return <View style={{flex:1,backgroundColor: '#000a12'}}>
			<Header 
			rightComponent={{ icon: 'menu', onPress: () => this.props.navigation.navigate('DrawerOpen'), color: '#fff' }}
	        centerComponent={{ text: 'Add Friends', 
	        						  style:{fontSize: 18, color:'white'} }}
	        leftComponent={{ icon: 'home', color: '#fff' }}				  
	        outerContainerStyles={{backgroundColor:'#455a64'}}
    		/>
    		<SearchBar onPressSearch={this.onPressSearch}/>
			</View>

	}
}

