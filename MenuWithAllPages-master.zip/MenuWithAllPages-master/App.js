import React from 'react';
import { Button, Text, Platform, ScrollView, StyleSheet } from 'react-native';
import{DrawerNavigator} from 'react-navigation'

import FirstScreen from './screens/FirstScreen';
import SecondScreen from './screens/SecondScreen';
import ThirdScreen from './screens/ThirdScreen';
import FourthScreen from './screens/FourthScreen';
import FifthScreen from './screens/FifthScreen';
import SixthScreen from './screens/SixthScreen';
import SeventhScreen from './screens/SeventhScreen';
import SearchBar from './components/SearchBar';

const DrawerExample= DrawerNavigator(
   {
      Profile:{
        path:'/',
        screen:FirstScreen,
      },
      MyFriends:{
        path:'/',
        screen:SecondScreen,
      },
      AddFriends:{
        path:'/',
        screen:ThirdScreen,
      },
      MemoriesSent:{
        path:'/',
        screen:FourthScreen,
      },
      UploadMemory:{
        path:'/',
        screen:FifthScreen,
      },
      Camera:{
        path:'/',
        screen:SixthScreen,
      },
      SignOut:{
        path:'/',
        screen:SeventhScreen
      },
    },
      

      {
      //Drawer Specs
      initialRouteName:'Profile',
      drawerPosition:'left',
      drawerWidth: 250,
      contentOptions:{
      activeTintColor:'#33ffbb',
      }
}
);
export default DrawerExample;

